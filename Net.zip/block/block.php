<?php
session_start();
$allowed_countries = array('DE', 'MA');
$ip = $_SERVER['REMOTE_ADDR'];

function getIpInfo($ip = '')
{
    $ipinfo = file_get_contents("https://pro.ip-api.com/json/" . $ip . "?key=s3DD9L9nYAxD9mz");
    $ipinfo_json = json_decode($ipinfo, true);
    return $ipinfo_json;
}

$visitor_ip = $_SERVER['REMOTE_ADDR'];
$ipinfo_json = getIpInfo($visitor_ip);
$country_code = "{$ipinfo_json['countryCode']}";

if (!in_array($country_code, $allowed_countries))
{
    die('HTTP/1.0 404 Not Found');
}
?>

